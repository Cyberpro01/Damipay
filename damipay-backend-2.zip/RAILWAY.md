# Deploy Dami Pay API on Railway (free, no domain needed)

Railway gives you a public URL like:
`https://damipay-production-xxxx.up.railway.app`

## Steps

### 1. Create accounts
1. Sign up at https://railway.app (GitHub login is easiest)
2. Sign up at https://github.com if you don’t have it

### 2. Put the code on GitHub
1. Unzip `damipay-backend.zip`
2. Create a new GitHub repo (e.g. `damipay-backend`)
3. Upload the unzipped folder contents to that repo  
   (or use GitHub Desktop / `git push`)

### 3. New project on Railway
1. Railway Dashboard → **New Project**
2. **Deploy from GitHub repo** → select `damipay-backend`
3. Wait for the first deploy (it may fail once — that’s OK before Postgres)

### 4. Add PostgreSQL
1. In the same Railway project → **+ New** → **Database** → **PostgreSQL**
2. Open your **API service** → **Variables**
3. Railway usually links `DATABASE_URL` automatically when Postgres is in the same project  
   If not: open Postgres → Variables → copy `DATABASE_URL` → paste into the API service variables

### 5. Set environment variables (API service → Variables)
| Name | Value |
|------|--------|
| `JWT_SECRET` | any long random string (e.g. `dami-pay-secret-2026-xyz`) |
| `JWT_EXPIRES_IN` | `7d` |
| `NODE_ENV` | `production` |
| `REFERRAL_BONUS_AMOUNT` | `500` |
| `REFERRAL_BONUS_CURRENCY` | `NGN` |
| `MIN_WITHDRAWAL` | `1000` |
| `DATABASE_URL` | (from Postgres — often auto-set) |

`PORT` is set by Railway automatically — don’t force it.

### 6. Redeploy
Railway → API service → **Deploy** / **Redeploy**

### 7. Public URL
API service → **Settings** → **Networking** → **Generate Domain**

You get something like:
`https://damipay-production-xxxx.up.railway.app`

### 8. Test on your phone
Open:
- `https://YOUR-URL/` → should show API name
- `https://YOUR-URL/health` → `{"ok":true}`

Login:
```bash
curl -X POST https://YOUR-URL/auth/login \
  -H "Content-Type: application/json" \
  -d '{"emailOrUsername":"admin@damipay.com","password":"admin123"}'
```

Admin: `admin@damipay.com` / `admin123`

## Notes
- No custom domain required
- Free tier is enough for testing
- Data lives in Railway Postgres (survives restarts)
- Change the admin password after first login in a real app
