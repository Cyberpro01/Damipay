import { PrismaClient, Role } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Dami Pay...');

  const adminPass = await bcrypt.hash('admin123', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@damipay.com' },
    update: {},
    create: {
      email: 'admin@damipay.com',
      username: 'admin',
      passwordHash: adminPass,
      firstName: 'Admin',
      lastName: 'Dami',
      referralCode: 'ADMIN001',
      preferredCurrency: 'NGN',
      role: Role.ADMIN,
      xp: 0,
      level: 1,
    },
  });

  await prisma.wallet.upsert({
    where: { userId_currency: { userId: admin.id, currency: 'NGN' } },
    update: {},
    create: { userId: admin.id, currency: 'NGN', balance: 0 },
  });

  const existingTasks = await prisma.task.count();
  if (existingTasks > 0) {
    console.log(`Tasks already exist (${existingTasks}). Skipping task seed.`);
    console.log('✅ Seed complete (admin only)');
    console.log('Admin login: admin@damipay.com / admin123');
    return;
  }

  const tasks = [
    // Level 1
    {
      title: 'Read Welcome Blog',
      description: 'Read the official welcome post and confirm you finished it.',
      type: 'BLOG' as const,
      rewardAmount: 50,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 1,
      xpReward: 15,
      allowRepeat: false,
    },
    {
      title: 'Complete Your Profile',
      description: 'Confirm your name and preferred currency are set.',
      type: 'OTHER' as const,
      rewardAmount: 80,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 1,
      xpReward: 20,
      allowRepeat: false,
    },
    {
      title: 'Daily Check-in',
      description: 'Claim your daily login reward. Resets every day.',
      type: 'DAILY' as const,
      rewardAmount: 25,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 1,
      xpReward: 10,
      allowRepeat: true,
    },
    {
      title: 'Invite Your First Friend',
      description: 'Share your referral code and get one successful signup.',
      type: 'REFERRAL' as const,
      rewardAmount: 300,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 1,
      xpReward: 40,
      allowRepeat: false,
      maxCompletions: 1,
    },
    {
      title: 'Follow Dami Pay on X',
      description: 'Follow the official account and upload a screenshot.',
      type: 'SOCIAL' as const,
      rewardAmount: 100,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 1,
      xpReward: 25,
      allowRepeat: false,
    },

    // Level 2
    {
      title: 'Watch Product Intro Video',
      description: 'Watch the 60-second Dami Pay intro.',
      type: 'VIDEO' as const,
      rewardAmount: 60,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 2,
      xpReward: 20,
      allowRepeat: false,
    },
    {
      title: 'Join the Telegram Channel',
      description: 'Join the community channel and submit proof.',
      type: 'SOCIAL' as const,
      rewardAmount: 120,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 2,
      xpReward: 30,
      allowRepeat: false,
    },
    {
      title: 'Read: How Withdrawals Work',
      description: 'Read the withdrawal guide blog.',
      type: 'BLOG' as const,
      rewardAmount: 70,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 2,
      xpReward: 20,
      allowRepeat: false,
    },

    // Level 3
    {
      title: 'Share Dami Pay on WhatsApp Status',
      description: 'Post your referral link on status and upload a screenshot.',
      type: 'SOCIAL' as const,
      rewardAmount: 150,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 3,
      xpReward: 35,
      allowRepeat: false,
    },
    {
      title: 'Short Feedback Survey',
      description: 'Answer 5 questions about the app experience.',
      type: 'SURVEY' as const,
      rewardAmount: 200,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 3,
      xpReward: 40,
      allowRepeat: false,
    },
    {
      title: 'Invite 3 Friends',
      description: 'Get 3 successful referrals total.',
      type: 'REFERRAL' as const,
      rewardAmount: 1000,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 3,
      xpReward: 80,
      allowRepeat: false,
      maxCompletions: 1,
    },

    // Level 4
    {
      title: 'Watch Partner Ad',
      description: 'Watch a short partner ad to earn extra.',
      type: 'VIDEO' as const,
      rewardAmount: 90,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 4,
      xpReward: 25,
      allowRepeat: true,
    },
    {
      title: 'Read: Safe Earning Tips',
      description: 'Read the safety blog so you avoid fake platforms.',
      type: 'BLOG' as const,
      rewardAmount: 80,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 4,
      xpReward: 25,
      allowRepeat: false,
    },

    // Level 5
    {
      title: 'Follow on Instagram',
      description: 'Follow @damipay and submit proof.',
      type: 'SOCIAL' as const,
      rewardAmount: 180,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 5,
      xpReward: 40,
      allowRepeat: false,
    },
    {
      title: 'Weekly Ambition Survey',
      description: 'Tell us how you plan to use your earnings.',
      type: 'SURVEY' as const,
      rewardAmount: 350,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 5,
      xpReward: 50,
      allowRepeat: false,
    },
    {
      title: 'Invite 10 Friends',
      description: 'Hit 10 successful referrals.',
      type: 'REFERRAL' as const,
      rewardAmount: 4000,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 5,
      xpReward: 150,
      allowRepeat: false,
      maxCompletions: 1,
    },

    // Level 6–7
    {
      title: 'Create a Review Video',
      description: 'Record a short honest review and submit the link.',
      type: 'VIDEO' as const,
      rewardAmount: 800,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 6,
      xpReward: 80,
      allowRepeat: false,
    },
    {
      title: 'Community Ambassador Check-in',
      description: 'Weekly ambassador activity confirmation.',
      type: 'DAILY' as const,
      rewardAmount: 150,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 7,
      xpReward: 35,
      allowRepeat: true,
    },

    // Level 8–10
    {
      title: 'Host a Mini Referral Drive',
      description: 'Bring 5 new users in one week and submit names/usernames.',
      type: 'REFERRAL' as const,
      rewardAmount: 8000,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 8,
      xpReward: 200,
      allowRepeat: false,
      maxCompletions: 1,
    },
    {
      title: 'Titan Feedback Call Form',
      description: 'Fill the high-level product feedback form.',
      type: 'SURVEY' as const,
      rewardAmount: 2500,
      rewardCurrency: 'NGN',
      requiresProof: false,
      minLevel: 9,
      xpReward: 120,
      allowRepeat: false,
    },
    {
      title: 'Dami King Challenge',
      description: 'Max-rank exclusive challenge. Proof required.',
      type: 'OTHER' as const,
      rewardAmount: 15000,
      rewardCurrency: 'NGN',
      requiresProof: true,
      minLevel: 10,
      xpReward: 300,
      allowRepeat: false,
      maxCompletions: 1,
    },
  ];

  await prisma.task.createMany({ data: tasks });

  console.log(`✅ Seed complete — ${tasks.length} tasks across 10 levels`);
  console.log('Admin login: admin@damipay.com / admin123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
