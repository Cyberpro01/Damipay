# Dami Pay Backend

Task-based rewards + referral + multi-currency wallet platform (inspired by Filora-style earning apps).  
**Backend only** – no UI copied.

## Features

- **Auth**: Register / Login (JWT)
- **Referral system**: Unique codes, signup bonus to referrer
- **Tasks**: Create (admin), list, complete (auto or proof-based). Daily tasks repeat once per day. Tasks can lock until you reach a min level.
- **Levels (1–10)**: Earn XP from tasks. Each level-up pays a cash bonus. Ranks: Starter → Hustler → Grinder → Earner → Pro → Elite → Champion → Legend → Titan → Dami King.
- **Wallet**: Multi-currency balances
- **Transactions**: Full history of earns / bonuses / withdrawals / level bonuses
- **Withdrawals**: Request → admin approve / reject (with refund)
- **Admin role**: Create tasks, approve completions & withdrawals

## Tech Stack

- Node.js + Express + TypeScript
- Prisma + SQLite (easy local start – switch to Postgres later)
- JWT + bcrypt
- Zod validation

## Quick Start

```bash
# 1. Install
npm install

# 2. Generate Prisma client + create DB
npx prisma generate
npx prisma db push

# 3. Seed admin + sample tasks
npm run db:seed

# 4. Run
npm run dev
```

Server starts at `http://localhost:4000`

### Default Admin
- Email: `admin@damipay.com`
- Password: `admin123`

## API Endpoints

### Auth
| Method | Path | Body | Description |
|--------|------|------|-------------|
| POST | /auth/register | firstName, lastName, username, email, password, preferredCurrency?, referralCode? | Create account |
| POST | /auth/login | emailOrUsername, password | Get JWT |

### User (Bearer token required)
| Method | Path | Description |
|--------|------|-------------|
| GET | /user/me | Profile + wallets + XP/level progress |
| GET | /user/levels | Full 10-level table + your progress |
| GET | /user/wallets | All currency balances |
| GET | /user/transactions | Recent transactions |
| GET | /user/referrals | List of users you referred |

### Tasks
| Method | Path | Description |
|--------|------|-------------|
| GET | /tasks | List active tasks (+ your status) |
| POST | /tasks/:id/complete | Complete task (proofUrl optional) |
| POST | /tasks | **Admin** – create task |
| PATCH | /tasks/completions/:id/approve | **Admin** – approve pending proof |

### Withdrawals
| Method | Path | Description |
|--------|------|-------------|
| POST | /withdrawals | Request withdrawal (amount, currency, method, details) |
| GET | /withdrawals | Your withdrawal history |
| GET | /withdrawals/admin/all | **Admin** – all requests |
| PATCH | /withdrawals/:id/approve | **Admin** |
| PATCH | /withdrawals/:id/reject | **Admin** (refunds balance) |

## Example Register

```json
POST /auth/register
{
  "firstName": "Dami",
  "lastName": "Pay",
  "username": "damipay",
  "email": "dami@example.com",
  "password": "secret123",
  "preferredCurrency": "NGN",
  "referralCode": "ADMIN001"
}
```

## Switching to PostgreSQL

1. Change `prisma/schema.prisma` datasource to `provider = "postgresql"`
2. Update `DATABASE_URL` in `.env`
3. Run `npx prisma db push`

## Next Steps (when you’re ready)

- Frontend (React / Flutter / whatever)
- Email verification / OTP
- Real payment gateway for withdrawals
- Rate limiting, more robust proof verification
- Levels / ranking system

Built for the Dami Pay project 🚀
