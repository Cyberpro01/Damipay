import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { hashPassword, comparePassword, signToken, generateReferralCode } from '../utils/auth.js';
import { registerSchema, loginSchema } from '../utils/validation.js';
import { Role } from '@prisma/client';

const router = Router();

// POST /auth/register
router.post('/register', async (req, res) => {
  try {
    const body = registerSchema.parse(req.body);

    // Check uniqueness
    const existing = await prisma.user.findFirst({
      where: {
        OR: [{ email: body.email.toLowerCase() }, { username: body.username.toLowerCase() }],
      },
    });
    if (existing) {
      return res.status(409).json({ error: 'Email or username already taken' });
    }

    // Resolve referrer
    let referredById: string | undefined;
    if (body.referralCode) {
      const referrer = await prisma.user.findUnique({
        where: { referralCode: body.referralCode.toUpperCase() },
      });
      if (!referrer) {
        return res.status(400).json({ error: 'Invalid referral code' });
      }
      referredById = referrer.id;
    }

    const passwordHash = await hashPassword(body.password);
    const referralCode = generateReferralCode(body.username);

    const user = await prisma.user.create({
      data: {
        email: body.email.toLowerCase(),
        username: body.username.toLowerCase(),
        passwordHash,
        firstName: body.firstName,
        lastName: body.lastName,
        preferredCurrency: body.preferredCurrency.toUpperCase(),
        referralCode,
        referredById,
      },
    });

    // Create default wallet
    await prisma.wallet.create({
      data: {
        userId: user.id,
        currency: user.preferredCurrency,
        balance: 0,
      },
    });

    // Pay referral bonus if applicable
    if (referredById) {
      const bonusAmount = Number(process.env.REFERRAL_BONUS_AMOUNT) || 500;
      const bonusCurrency = process.env.REFERRAL_BONUS_CURRENCY || 'NGN';

      // Ensure referrer has wallet for that currency
      let referrerWallet = await prisma.wallet.findUnique({
        where: { userId_currency: { userId: referredById, currency: bonusCurrency } },
      });
      if (!referrerWallet) {
        referrerWallet = await prisma.wallet.create({
          data: { userId: referredById, currency: bonusCurrency, balance: 0 },
        });
      }

      await prisma.$transaction([
        prisma.wallet.update({
          where: { id: referrerWallet.id },
          data: { balance: { increment: bonusAmount } },
        }),
        prisma.transaction.create({
          data: {
            userId: referredById,
            type: 'REFERRAL_BONUS',
            amount: bonusAmount,
            currency: bonusCurrency,
            status: 'COMPLETED',
            description: `Referral bonus for inviting ${user.username}`,
            meta: JSON.stringify({ referredUserId: user.id }),
          },
        }),
      ]);
    }

    const token = signToken({
      userId: user.id,
      role: user.role,
      email: user.email,
    });

    res.status(201).json({
      message: 'Account created successfully',
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        referralCode: user.referralCode,
        preferredCurrency: user.preferredCurrency,
        role: user.role,
      },
    });
  } catch (err: any) {
    if (err.name === 'ZodError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors });
    }
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /auth/login
router.post('/login', async (req, res) => {
  try {
    const body = loginSchema.parse(req.body);

    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { email: body.emailOrUsername.toLowerCase() },
          { username: body.emailOrUsername.toLowerCase() },
        ],
        isActive: true,
      },
    });

    if (!user || !(await comparePassword(body.password, user.passwordHash))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = signToken({
      userId: user.id,
      role: user.role,
      email: user.email,
    });

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        referralCode: user.referralCode,
        preferredCurrency: user.preferredCurrency,
        role: user.role,
      },
    });
  } catch (err: any) {
    if (err.name === 'ZodError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors });
    }
    console.error(err);
    res.status(500).json({ error: 'Login failed' });
  }
});

export default router;
