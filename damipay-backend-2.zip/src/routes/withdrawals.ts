import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth.js';
import { withdrawSchema } from '../utils/validation.js';

const router = Router();
const MIN_WITHDRAWAL = Number(process.env.MIN_WITHDRAWAL) || 1000;

// POST /withdrawals - request withdrawal
router.post('/', authenticate, async (req: AuthRequest, res) => {
  try {
    const body = withdrawSchema.parse(req.body);

    if (body.amount < MIN_WITHDRAWAL) {
      return res.status(400).json({ error: `Minimum withdrawal is ${MIN_WITHDRAWAL} ${body.currency}` });
    }

    const wallet = await prisma.wallet.findUnique({
      where: { userId_currency: { userId: req.user!.userId, currency: body.currency.toUpperCase() } },
    });

    if (!wallet || wallet.balance < body.amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    // Deduct immediately (hold) and create pending withdrawal + transaction
    const [withdrawal] = await prisma.$transaction([
      prisma.withdrawal.create({
        data: {
          userId: req.user!.userId,
          amount: body.amount,
          currency: body.currency.toUpperCase(),
          method: body.method,
          details: JSON.stringify(body.details),
          status: 'PENDING',
        },
      }),
      prisma.wallet.update({
        where: { id: wallet.id },
        data: { balance: { decrement: body.amount } },
      }),
      prisma.transaction.create({
        data: {
          userId: req.user!.userId,
          type: 'WITHDRAW',
          amount: body.amount,
          currency: body.currency.toUpperCase(),
          status: 'PENDING',
          description: `Withdrawal request via ${body.method}`,
        },
      }),
    ]);

    res.status(201).json({
      message: 'Withdrawal request submitted',
      withdrawal,
    });
  } catch (err: any) {
    if (err.name === 'ZodError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to create withdrawal' });
  }
});

// GET /withdrawals - user's own withdrawals
router.get('/', authenticate, async (req: AuthRequest, res) => {
  try {
    const list = await prisma.withdrawal.findMany({
      where: { userId: req.user!.userId },
      orderBy: { createdAt: 'desc' },
    });
    res.json(list);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch withdrawals' });
  }
});

// ===== ADMIN =====

// GET /withdrawals/admin/all
router.get('/admin/all', authenticate, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const list = await prisma.withdrawal.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { id: true, username: true, email: true } },
      },
    });
    res.json(list);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch' });
  }
});

// PATCH /withdrawals/:id/approve
router.patch('/:id/approve', authenticate, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const withdrawal = await prisma.withdrawal.findUnique({ where: { id: req.params.id } });
    if (!withdrawal || withdrawal.status !== 'PENDING') {
      return res.status(400).json({ error: 'Invalid withdrawal' });
    }

    await prisma.withdrawal.update({
      where: { id: withdrawal.id },
      data: { status: 'APPROVED', processedAt: new Date(), adminNote: req.body.note || null },
    });

    // Mark related transaction completed (optional - find by amount/user/time)
    await prisma.transaction.updateMany({
      where: {
        userId: withdrawal.userId,
        type: 'WITHDRAW',
        amount: withdrawal.amount,
        status: 'PENDING',
      },
      data: { status: 'COMPLETED' },
    });

    res.json({ message: 'Withdrawal approved' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to approve' });
  }
});

// PATCH /withdrawals/:id/reject  (refund balance)
router.patch('/:id/reject', authenticate, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const withdrawal = await prisma.withdrawal.findUnique({ where: { id: req.params.id } });
    if (!withdrawal || withdrawal.status !== 'PENDING') {
      return res.status(400).json({ error: 'Invalid withdrawal' });
    }

    const wallet = await prisma.wallet.findUnique({
      where: { userId_currency: { userId: withdrawal.userId, currency: withdrawal.currency } },
    });

    await prisma.$transaction([
      prisma.withdrawal.update({
        where: { id: withdrawal.id },
        data: { status: 'REJECTED', processedAt: new Date(), adminNote: req.body.note || 'Rejected by admin' },
      }),
      ...(wallet
        ? [
            prisma.wallet.update({
              where: { id: wallet.id },
              data: { balance: { increment: withdrawal.amount } },
            }),
          ]
        : []),
      prisma.transaction.updateMany({
        where: {
          userId: withdrawal.userId,
          type: 'WITHDRAW',
          amount: withdrawal.amount,
          status: 'PENDING',
        },
        data: { status: 'CANCELLED' },
      }),
    ]);

    res.json({ message: 'Withdrawal rejected and balance refunded' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to reject' });
  }
});

export default router;
