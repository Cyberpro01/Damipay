import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticate, requireAdmin, AuthRequest } from '../middleware/auth.js';
import { createTaskSchema, completeTaskSchema } from '../utils/validation.js';
import { payTaskReward } from '../utils/rewards.js';

const router = Router();

function isSameUtcDay(a: Date, b: Date) {
  return (
    a.getUTCFullYear() === b.getUTCFullYear() &&
    a.getUTCMonth() === b.getUTCMonth() &&
    a.getUTCDate() === b.getUTCDate()
  );
}

// GET /tasks
router.get('/', authenticate, async (req: AuthRequest, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: { level: true },
    });
    const userLevel = user?.level ?? 1;

    const tasks = await prisma.task.findMany({
      where: { isActive: true },
      orderBy: [{ minLevel: 'asc' }, { createdAt: 'desc' }],
    });

    const completions = await prisma.taskCompletion.findMany({
      where: { userId: req.user!.userId },
      orderBy: { createdAt: 'desc' },
      select: { taskId: true, status: true, completedAt: true, createdAt: true },
    });

    const result = tasks.map((t) => {
      const mine = completions.filter((c) => c.taskId === t.id);
      const latest = mine[0] ?? null;
      const completedToday =
        t.allowRepeat &&
        latest?.status === 'COMPLETED' &&
        latest.completedAt &&
        isSameUtcDay(latest.completedAt, new Date());

      const locked = userLevel < t.minLevel;

      return {
        ...t,
        locked,
        unlockLevel: t.minLevel,
        userStatus: latest?.status ?? null,
        completedToday: !!completedToday,
        timesCompleted: mine.filter((c) => c.status === 'COMPLETED').length,
      };
    });

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

// POST /tasks/:id/complete
router.post('/:id/complete', authenticate, async (req: AuthRequest, res) => {
  try {
    const taskId = req.params.id;
    const body = completeTaskSchema.parse(req.body);

    const [task, user] = await Promise.all([
      prisma.task.findUnique({ where: { id: taskId } }),
      prisma.user.findUnique({ where: { id: req.user!.userId } }),
    ]);

    if (!task || !task.isActive) {
      return res.status(404).json({ error: 'Task not found or inactive' });
    }
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (user.level < task.minLevel) {
      return res.status(403).json({
        error: `This task unlocks at level ${task.minLevel}. You are level ${user.level}.`,
      });
    }

    const previous = await prisma.taskCompletion.findMany({
      where: { userId: user.id, taskId },
      orderBy: { createdAt: 'desc' },
    });

    const lastCompleted = previous.find((c) => c.status === 'COMPLETED');

    if (!task.allowRepeat && lastCompleted) {
      return res.status(400).json({ error: 'Task already completed' });
    }

    if (task.allowRepeat && lastCompleted?.completedAt && isSameUtcDay(lastCompleted.completedAt, new Date())) {
      return res.status(400).json({ error: 'Already completed today. Come back tomorrow.' });
    }

    if (task.maxCompletions) {
      const doneCount = previous.filter((c) => c.status === 'COMPLETED').length;
      if (doneCount >= task.maxCompletions) {
        return res.status(400).json({ error: 'Maximum completions reached for this task' });
      }
    }

    const status = task.requiresProof ? 'PENDING' : 'COMPLETED';

    const completion = await prisma.taskCompletion.create({
      data: {
        userId: user.id,
        taskId,
        status,
        proofUrl: body.proofUrl,
        completedAt: status === 'COMPLETED' ? new Date() : null,
        rewardPaid: false,
      },
    });

    let levelUp = null;
    let saved = completion;
    if (status === 'COMPLETED') {
      levelUp = await payTaskReward(user.id, task);
      saved = await prisma.taskCompletion.update({
        where: { id: completion.id },
        data: { rewardPaid: true },
      });
    }

    res.json({
      message: status === 'COMPLETED' ? 'Task completed! Reward added to wallet.' : 'Task submitted for review.',
      completion: saved,
      xpGained: status === 'COMPLETED' ? task.xpReward : 0,
      levelUp,
    });
  } catch (err: any) {
    if (err.name === 'ZodError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to complete task' });
  }
});

// POST /tasks (admin create)
router.post('/', authenticate, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const body = createTaskSchema.parse(req.body);
    const task = await prisma.task.create({ data: body });
    res.status(201).json(task);
  } catch (err: any) {
    if (err.name === 'ZodError') {
      return res.status(400).json({ error: 'Validation failed', details: err.errors });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to create task' });
  }
});

router.patch('/completions/:completionId/approve', authenticate, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const completion = await prisma.taskCompletion.findUnique({
      where: { id: req.params.completionId },
      include: { task: true },
    });
    if (!completion) return res.status(404).json({ error: 'Completion not found' });
    if (completion.status !== 'PENDING') {
      return res.status(400).json({ error: 'Only pending completions can be approved' });
    }

    await prisma.taskCompletion.update({
      where: { id: completion.id },
      data: { status: 'COMPLETED', completedAt: new Date(), rewardPaid: true },
    });

    const levelUp = await payTaskReward(completion.userId, completion.task);

    res.json({ message: 'Completion approved and reward paid', levelUp });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to approve' });
  }
});

export default router;
