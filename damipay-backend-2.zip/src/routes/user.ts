import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { authenticate, AuthRequest } from '../middleware/auth.js';
import { getLevelProgress, LEVELS } from '../utils/levels.js';

const router = Router();

// GET /user/me
router.get('/me', authenticate, async (req: AuthRequest, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: {
        id: true,
        email: true,
        username: true,
        firstName: true,
        lastName: true,
        referralCode: true,
        preferredCurrency: true,
        role: true,
        xp: true,
        level: true,
        createdAt: true,
        wallets: true,
        _count: { select: { referrals: true } },
      },
    });

    if (!user) return res.status(404).json({ error: 'User not found' });

    res.json({
      ...user,
      referralCount: user._count.referrals,
      rank: getLevelProgress(user.xp),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// GET /user/levels
router.get('/levels', authenticate, async (req: AuthRequest, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.userId },
      select: { xp: true, level: true },
    });
    if (!user) return res.status(404).json({ error: 'User not found' });

    res.json({
      current: getLevelProgress(user.xp),
      levels: LEVELS,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch levels' });
  }
});

// GET /user/wallets
router.get('/wallets', authenticate, async (req: AuthRequest, res) => {
  try {
    const wallets = await prisma.wallet.findMany({
      where: { userId: req.user!.userId },
    });
    res.json(wallets);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch wallets' });
  }
});

// GET /user/transactions
router.get('/transactions', authenticate, async (req: AuthRequest, res) => {
  try {
    const transactions = await prisma.transaction.findMany({
      where: { userId: req.user!.userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json(transactions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

// GET /user/referrals
router.get('/referrals', authenticate, async (req: AuthRequest, res) => {
  try {
    const referrals = await prisma.user.findMany({
      where: { referredById: req.user!.userId },
      select: {
        id: true,
        username: true,
        firstName: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    res.json(referrals);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch referrals' });
  }
});

export default router;
