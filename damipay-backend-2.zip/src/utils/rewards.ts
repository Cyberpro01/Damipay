import { prisma } from './prisma.js';
import { getLevelForXp, LEVELS } from './levels.js';

export async function creditWallet(
  userId: string,
  amount: number,
  currency: string,
  type: 'EARN' | 'REFERRAL_BONUS' | 'LEVEL_BONUS' | 'ADJUSTMENT',
  description: string,
  meta?: string
) {
  let wallet = await prisma.wallet.findUnique({
    where: { userId_currency: { userId, currency } },
  });
  if (!wallet) {
    wallet = await prisma.wallet.create({
      data: { userId, currency, balance: 0 },
    });
  }

  await prisma.$transaction([
    prisma.wallet.update({
      where: { id: wallet.id },
      data: { balance: { increment: amount } },
    }),
    prisma.transaction.create({
      data: {
        userId,
        type,
        amount,
        currency,
        status: 'COMPLETED',
        description,
        meta,
      },
    }),
  ]);
}

export async function awardXp(userId: string, xpGain: number) {
  if (xpGain <= 0) return { leveledUp: false, newLevel: null, bonuses: [] as string[] };

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return { leveledUp: false, newLevel: null, bonuses: [] as string[] };

  const newXp = user.xp + xpGain;
  const newRank = getLevelForXp(newXp);
  const bonuses: string[] = [];

  await prisma.user.update({
    where: { id: userId },
    data: { xp: newXp, level: newRank.level },
  });

  if (newRank.level > user.level) {
    for (const lvl of LEVELS) {
      if (lvl.level > user.level && lvl.level <= newRank.level && lvl.bonusAmount > 0) {
        await creditWallet(
          userId,
          lvl.bonusAmount,
          lvl.bonusCurrency,
          'LEVEL_BONUS',
          `Level-up bonus: reached ${lvl.name} (Lv.${lvl.level})`,
          JSON.stringify({ level: lvl.level })
        );
        bonuses.push(`Lv.${lvl.level} ${lvl.name} +${lvl.bonusAmount} ${lvl.bonusCurrency}`);
      }
    }
    return { leveledUp: true, newLevel: newRank, bonuses };
  }

  return { leveledUp: false, newLevel: newRank, bonuses };
}

export async function payTaskReward(
  userId: string,
  task: { rewardAmount: number; rewardCurrency: string; title: string; xpReward: number }
) {
  await creditWallet(
    userId,
    task.rewardAmount,
    task.rewardCurrency,
    'EARN',
    `Reward for task: ${task.title}`
  );
  return awardXp(userId, task.xpReward);
}
