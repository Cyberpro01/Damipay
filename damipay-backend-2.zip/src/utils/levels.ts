export interface LevelDef {
  level: number;
  name: string;
  minXp: number;
  bonusAmount: number;
  bonusCurrency: string;
}

/** 10 ranks. XP is cumulative. Level-up pays a one-time cash bonus. */
export const LEVELS: LevelDef[] = [
  { level: 1, name: 'Starter', minXp: 0, bonusAmount: 0, bonusCurrency: 'NGN' },
  { level: 2, name: 'Hustler', minXp: 100, bonusAmount: 200, bonusCurrency: 'NGN' },
  { level: 3, name: 'Grinder', minXp: 300, bonusAmount: 500, bonusCurrency: 'NGN' },
  { level: 4, name: 'Earner', minXp: 700, bonusAmount: 1000, bonusCurrency: 'NGN' },
  { level: 5, name: 'Pro', minXp: 1500, bonusAmount: 2000, bonusCurrency: 'NGN' },
  { level: 6, name: 'Elite', minXp: 2800, bonusAmount: 4000, bonusCurrency: 'NGN' },
  { level: 7, name: 'Champion', minXp: 5000, bonusAmount: 7500, bonusCurrency: 'NGN' },
  { level: 8, name: 'Legend', minXp: 8500, bonusAmount: 12000, bonusCurrency: 'NGN' },
  { level: 9, name: 'Titan', minXp: 14000, bonusAmount: 20000, bonusCurrency: 'NGN' },
  { level: 10, name: 'Dami King', minXp: 22000, bonusAmount: 50000, bonusCurrency: 'NGN' },
];

export function getLevelForXp(xp: number): LevelDef {
  let current = LEVELS[0];
  for (const lvl of LEVELS) {
    if (xp >= lvl.minXp) current = lvl;
  }
  return current;
}

export function getNextLevel(level: number): LevelDef | null {
  return LEVELS.find((l) => l.level === level + 1) ?? null;
}

export function getLevelProgress(xp: number) {
  const current = getLevelForXp(xp);
  const next = getNextLevel(current.level);
  const xpIntoLevel = xp - current.minXp;
  const xpNeeded = next ? next.minXp - current.minXp : 0;
  const percent = next ? Math.min(100, Math.round((xpIntoLevel / xpNeeded) * 100)) : 100;

  return {
    level: current.level,
    name: current.name,
    xp,
    nextLevel: next?.level ?? null,
    nextLevelName: next?.name ?? null,
    xpToNext: next ? Math.max(0, next.minXp - xp) : 0,
    progressPercent: percent,
    maxLevel: LEVELS[LEVELS.length - 1].level,
  };
}
