import { z } from 'zod';

export const registerSchema = z.object({
  firstName: z.string().min(1).max(50),
  lastName: z.string().min(1).max(50),
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers and underscore'),
  email: z.string().email(),
  password: z.string().min(6).max(100),
  preferredCurrency: z.string().min(3).max(5).default('NGN'),
  referralCode: z.string().optional(),
});

export const loginSchema = z.object({
  emailOrUsername: z.string().min(1),
  password: z.string().min(1),
});

export const createTaskSchema = z.object({
  title: z.string().min(3).max(200),
  description: z.string().optional(),
  type: z.enum(['BLOG', 'SOCIAL', 'DAILY', 'REFERRAL', 'VIDEO', 'SURVEY', 'OTHER']).default('OTHER'),
  rewardAmount: z.number().positive(),
  rewardCurrency: z.string().default('NGN'),
  maxCompletions: z.number().int().positive().optional(),
  requiresProof: z.boolean().default(false),
  minLevel: z.number().int().min(1).max(10).default(1),
  xpReward: z.number().int().min(0).default(10),
  allowRepeat: z.boolean().default(false),
});

export const completeTaskSchema = z.object({
  proofUrl: z.string().url().optional(),
});

export const withdrawSchema = z.object({
  amount: z.number().positive(),
  currency: z.string().min(3).max(5),
  method: z.string().min(2),
  details: z.record(z.string()), // e.g. { bankName, accountNumber, accountName }
});
